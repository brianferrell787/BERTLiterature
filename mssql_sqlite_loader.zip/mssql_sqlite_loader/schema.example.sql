-- Example only. Use your own schema-only SQLite database for the real migration.
-- This matches mapping.example.json, not an assumed real SQL Server database.
PRAGMA foreign_keys = ON;

CREATE TABLE customers (
    customer_id INTEGER PRIMARY KEY,
    customer_name TEXT
);

CREATE TABLE transactions (
    transaction_id INTEGER PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(customer_id),
    amount TEXT,             -- Exact decimal representation; not SQLite DECIMAL/REAL.
    occurred_at TEXT,        -- ISO-style text, including available fractional digits/offset.
    payload BLOB
);

-- Non-unique secondary indexes are saved, removed in staging, and rebuilt after loading.
CREATE INDEX ix_transactions_customer ON transactions(customer_id);
CREATE INDEX ix_transactions_occurred ON transactions(occurred_at);
