"""Local SQLite and controlled-source tests. No real SQL Server/ODBC connection.
Run: python -m unittest -v test_loader.py
"""
from __future__ import annotations
import contextlib
import json
from pathlib import Path
import queue
import re
import sqlite3
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import mssql_to_sqlite as m


@contextlib.contextmanager
def database(path):
    db = sqlite3.connect(path)
    try:
        yield db
        db.commit()
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()


def column(name, typ="int", nullable=False, scale=0, precision=10):
    return {"name": name, "type": typ, "precision": precision, "scale": scale,
            "nullable": nullable, "encrypted": None}


class FakeCursor:
    def __init__(self, source):
        self.source = source
        self.rows = []
        self.offset = 0
        self.table = None
        self.arraysize = 1
        self.cancelled = False

    def execute(self, sql, *params):
        self.source.queries.append((sql, params))
        if sql.startswith("IF @@TRANCOUNT"):
            self.rows = []
            return self
        match = re.search(r"FROM \[dbo\]\.\[([^]]+)\]", sql)
        if not match:
            raise AssertionError(f"Unexpected mock SQL: {sql}")
        self.table = match[1]
        rows = list(self.source.tables[self.table]["rows"])
        if sql.startswith("SELECT TOP (0)"):
            self.rows = []
        elif sql.startswith("SELECT COUNT_BIG"):
            self.rows = [(len(rows),)]
        else:
            if " ORDER BY " in sql:
                keyname = self.source.tables[self.table]["pk"][0]
                index = [c["name"] for c in self.source.tables[self.table]["columns"]].index(keyname)
                rows.sort(key=lambda r: r[index])
                if params:
                    rows = [r for r in rows if r[index] > params[0]]
            self.rows = rows
        self.offset = 0
        return self

    def fetchone(self):
        if self.offset == len(self.rows):
            return None
        value = self.rows[self.offset]
        self.offset += 1
        return value

    def fetchmany(self, count):
        if self.source.fail_at is not None and self.source.fetched >= self.source.fail_at:
            raise OSError("Simulated disconnected network; PRIVATE VALUE must not appear in default error")
        values = self.rows[self.offset:self.offset + count]
        self.offset += len(values)
        self.source.fetched += len(values)
        return values

    def fetchall(self):
        remaining = self.rows[self.offset:]
        self.offset = len(self.rows)
        return remaining

    def close(self):
        pass

    def cancel(self):
        self.cancelled = True


class FakeSource:
    def __init__(self, tables, fail_at=None):
        self.tables = tables
        self.fail_at = fail_at
        self.fetched = 0
        self.closed = False
        self.queries = []

    def cursor(self):
        return FakeCursor(self)

    def close(self):
        self.closed = True


def mock_metadata(source, schema, table):
    assert schema == "dbo"
    t = source.tables[table]
    return t["columns"], t["pk"]


class Harness(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.template = self.root / "schema.sqlite"
        self.output = self.root / "copy.sqlite"
        self.mapping = self.root / "mapping.json"

    def tearDown(self):
        self.temp.cleanup()

    def setup_schema(self, sql, mappings):
        with database(self.template) as db:
            db.executescript(sql)
        self.mapping.write_text(json.dumps({"tables": mappings}))

    def args(self, *extra):
        return m.parser().parse_args([
            "--template", str(self.template), "--output", str(self.output),
            "--mapping", str(self.mapping), "--source-mode", "static", "--source-token", "fixture-v1",
            "--batch-rows", "2", "--commit-rows", "2", "--prefetch-batches", "1", *extra])

    def run_source(self, source, args):
        identity = {"server": "test", "database": "fixture", "database_created": "2020-01-01",
                    "read_only": True, "source_mode": args.source_mode, "source_token": args.source_token}
        with patch.object(m, "connect_source", return_value=(source, identity)), \
             patch.object(m, "fetch_metadata", side_effect=mock_metadata):
            m.run(args)

    def basic(self, *, pk=True, fail_at=None, rows=None, schema=None):
        self.setup_schema(schema or 'CREATE TABLE item(id INTEGER PRIMARY KEY, value TEXT); CREATE INDEX ix_value ON item(value);',
                          [{"target_table": "item"}])
        return FakeSource({"item": {"columns": [column("id"), column("value", "nvarchar", True)],
                                    "pk": ["id"] if pk else [],
                                    "rows": rows if rows is not None else [(i, f"v{i}") for i in range(-2, 6)]}}, fail_at)

    def stage(self):
        return self.output.with_name(self.output.name + ".loading.sqlite")

    def test_end_to_end_publish_and_schema_preserved(self):
        source = self.basic(rows=[(-2, "é\x00\n\"quoted\""), (0, None), (3, "")])
        with database(self.template) as db:
            original_hash = m.schema_fingerprint(db)
        self.run_source(source, self.args("--verify-hash"))
        self.assertTrue(source.closed)
        self.assertFalse(self.stage().exists())
        with database(self.output) as db:
            self.assertEqual(db.execute("SELECT * FROM item ORDER BY id").fetchall(), source.tables["item"]["rows"])
            self.assertEqual(original_hash, m.schema_fingerprint(db))
            self.assertEqual(db.execute("PRAGMA journal_mode").fetchone(), ("delete",))
            report = m.meta_get(db, "report")
            self.assertTrue(report["tables"][0]["value_hash_verified"])
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone(), ("ok",))
        with database(self.template) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM item").fetchone(), (0,))
        self.assertTrue(Path(str(self.output) + ".report.json").exists())
        self.assertFalse(Path(str(self.output) + "-wal").exists())

    def test_dry_run_creates_no_database(self):
        source = self.basic()
        self.run_source(source, self.args("--dry-run"))
        self.assertFalse(self.stage().exists())
        self.assertFalse(self.output.exists())
        self.assertTrue(any(sql.startswith("SELECT TOP (0)") for sql, _ in source.queries))
        self.assertTrue(source.closed)

    def test_empty_table_is_copied_and_verified(self):
        source = self.basic(rows=[])
        self.run_source(source, self.args("--verify-hash"))
        with database(self.output) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM item").fetchone()[0], 0)
            self.assertTrue(m.meta_get(db, "report")["tables"][0]["value_hash_verified"])

    def test_keyset_resume_negative_and_zero_keys(self):
        source = self.basic(fail_at=4)
        with self.assertRaises(m.LoadError):
            self.run_source(source, self.args("--verify-hash"))
        self.assertFalse(self.output.exists())
        with database(self.stage()) as db:
            state = m.progress_rows(db)["item"]
            self.assertEqual(state["rows"], 4)
            self.assertEqual(state["last_key"], 1)
        resumed = FakeSource(source.tables)
        self.run_source(resumed, self.args("--verify-hash", "--resume"))
        self.assertTrue(any(" WHERE [id] > ?" in sql and params == (1,) for sql, params in resumed.queries))
        with database(self.output) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM item").fetchone()[0], 8)
            self.assertTrue(m.meta_get(db, "report")["tables"][0]["value_hash_verified"])

    def test_incomplete_table_without_key_is_reloaded(self):
        source = self.basic(pk=False, fail_at=4, schema="CREATE TABLE item(id INTEGER, value TEXT)")
        with self.assertRaises(m.LoadError):
            self.run_source(source, self.args())
        self.run_source(FakeSource(source.tables), self.args("--resume"))
        with database(self.output) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM item").fetchone()[0], 8)

    def test_writer_failure_stops_prefetch_worker(self):
        source = self.basic(pk=False, rows=[(1, "duplicate")] * 100)
        with self.assertRaises(m.LoadError):
            self.run_source(source, self.args())
        self.assertTrue(source.closed)
        self.assertFalse(self.output.exists())

    def test_duplicate_does_not_get_ignored_by_schema(self):
        source = self.basic(rows=[(1, "a"), (1, "b")], schema="CREATE TABLE item(id INTEGER UNIQUE ON CONFLICT IGNORE, value TEXT)")
        # No source PK in this fixture; otherwise key ordering would reject it even earlier.
        source.tables["item"]["pk"] = []
        with self.assertRaises(m.LoadError):
            self.run_source(source, self.args())
        self.assertFalse(self.output.exists())
        with database(self.stage()) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM item").fetchone()[0], 0)
            self.assertEqual(m.progress_rows(db)["item"]["rows"], 0)

    def test_foreign_key_failure_prevents_publication(self):
        self.setup_schema("CREATE TABLE parent(id INTEGER PRIMARY KEY); CREATE TABLE child(id INTEGER PRIMARY KEY, parent_id INTEGER REFERENCES parent(id));",
                          [{"target_table": "child"}, {"target_table": "parent"}])
        source = FakeSource({"parent": {"columns": [column("id")], "pk": ["id"], "rows": []},
                             "child": {"columns": [column("id"), column("parent_id")], "pk": ["id"], "rows": [(1, 99)]}})
        with self.assertRaisesRegex(m.LoadError, "Foreign-key"):
            self.run_source(source, self.args())
        self.assertFalse(self.output.exists())

    def test_out_of_order_foreign_keys_succeed_after_all_tables(self):
        self.setup_schema("CREATE TABLE parent(id INTEGER PRIMARY KEY); CREATE TABLE child(id INTEGER PRIMARY KEY, parent_id INTEGER REFERENCES parent(id));",
                          [{"target_table": "child"}, {"target_table": "parent"}])
        source = FakeSource({"parent": {"columns": [column("id")], "pk": ["id"], "rows": [(99,)]},
                             "child": {"columns": [column("id"), column("parent_id")], "pk": ["id"], "rows": [(1, 99)]}})
        self.run_source(source, self.args("--verify-hash"))
        self.assertTrue(self.output.exists())

    def test_trigger_refused_unless_explicitly_deferred(self):
        source = self.basic(schema="CREATE TABLE item(id INTEGER PRIMARY KEY, value TEXT); CREATE TRIGGER change_it AFTER INSERT ON item BEGIN UPDATE item SET value='CHANGED' WHERE id=NEW.id; END;")
        with self.assertRaisesRegex(m.LoadError, "triggers"):
            self.run_source(source, self.args())
        self.run_source(FakeSource(source.tables), self.args("--defer-triggers", "--verify-hash"))
        with database(self.output) as db:
            self.assertEqual(db.execute("SELECT value FROM item WHERE id=0").fetchone()[0], "v0")
            db.execute("INSERT INTO item VALUES(100,'original')")
            self.assertEqual(db.execute("SELECT value FROM item WHERE id=100").fetchone()[0], "CHANGED")

    def test_snapshot_partial_resume_is_rejected(self):
        source = self.basic(fail_at=4)
        args = self.args("--source-mode", "snapshot")
        with self.assertRaises(m.LoadError):
            self.run_source(source, args)
        with self.assertRaisesRegex(m.LoadError, "disconnected live SNAPSHOT"):
            self.run_source(FakeSource(source.tables), self.args("--source-mode", "snapshot", "--resume"))

    def test_completed_snapshot_can_finalize_without_source(self):
        source = self.basic()
        args = self.args("--source-mode", "snapshot", "--verify-hash")
        with patch.object(m, "finalize", side_effect=m.LoadError("Simulate failure before validation")):
            with self.assertRaises(m.LoadError):
                self.run_source(source, args)
        with patch.object(m, "connect_source", side_effect=AssertionError("Must not reconnect")):
            m.run(self.args("--source-mode", "snapshot", "--verify-hash", "--resume"))
        self.assertTrue(self.output.exists())

    def test_config_change_prevents_resume(self):
        source = self.basic(fail_at=4)
        with self.assertRaises(m.LoadError):
            self.run_source(source, self.args())
        with self.assertRaisesRegex(m.LoadError, "configuration"):
            self.run_source(FakeSource(source.tables), self.args("--resume", "--verify-hash"))

    def test_source_count_change_prevents_resume(self):
        source = self.basic(fail_at=4)
        with self.assertRaises(m.LoadError):
            self.run_source(source, self.args())
        source.tables["item"]["rows"].append((88, "new"))
        with self.assertRaisesRegex(m.LoadError, "count changed"):
            self.run_source(FakeSource(source.tables), self.args("--resume"))

    def test_existing_output_not_overwritten(self):
        source = self.basic()
        self.output.write_bytes(b"important existing file")
        with self.assertRaisesRegex(m.LoadError, "not be overwritten"):
            self.run_source(source, self.args())
        self.assertEqual(self.output.read_bytes(), b"important existing file")

    def test_nonempty_template_rejected(self):
        source = self.basic(schema="CREATE TABLE item(id INTEGER PRIMARY KEY,value TEXT); INSERT INTO item VALUES(1,'seed');")
        with self.assertRaisesRegex(m.LoadError, "not empty"):
            self.run_source(source, self.args())

    def test_nullable_source_primary_key_rejected(self):
        source = self.basic()
        source.tables["item"]["columns"][0]["nullable"] = True
        with self.assertRaisesRegex(m.LoadError, "Nullable source"):
            self.run_source(source, self.args())

    def test_blob_decimal_and_temporal_roundtrip(self):
        self.setup_schema("CREATE TABLE item(id INTEGER PRIMARY KEY, amount TEXT, stamp TEXT, payload BLOB)", [{"target_table": "item"}])
        rows = [(1, "1234567890123456789012345678901234.5678", "2026-10-07T12:34:56.1234567+05:30", b"\x00\xff\n")]
        source = FakeSource({"item": {"columns": [column("id"), column("amount", "decimal", scale=4, precision=38),
                                                        column("stamp", "datetimeoffset"), column("payload", "varbinary")],
                                     "pk": ["id"], "rows": rows}})
        self.run_source(source, self.args("--verify-hash"))
        with database(self.output) as db:
            self.assertEqual(db.execute("SELECT * FROM item").fetchall(), rows)

    def test_scaled_decimal_roundtrip(self):
        self.setup_schema("CREATE TABLE item(id INTEGER PRIMARY KEY, amount INTEGER)", [{"target_table": "item"}])
        source = FakeSource({"item": {"columns": [column("id"), column("amount", "decimal", scale=2, precision=19)],
                                     "pk": ["id"], "rows": [(1, "-12.34"), (2, "0.00")]}})
        self.run_source(source, self.args("--decimal-mode", "scaled_integer", "--verify-hash"))
        with database(self.output) as db:
            self.assertEqual(db.execute("SELECT amount FROM item ORDER BY id").fetchall(), [(-1234,), (0,)])

    def test_hash_finds_value_change_without_row_count_change(self):
        source = self.basic()
        with patch.object(m, "finalize", side_effect=m.LoadError("fail before finalization")):
            with self.assertRaises(m.LoadError):
                self.run_source(source, self.args("--verify-hash"))
        with database(self.stage()) as db:
            db.execute("UPDATE item SET value='tampered' WHERE id=0")
        with self.assertRaisesRegex(m.LoadError, "hash mismatch"):
            self.run_source(FakeSource(source.tables), self.args("--resume", "--verify-hash"))

    def test_checkpoint_detects_extra_staging_rows(self):
        source = self.basic(fail_at=4)
        with self.assertRaises(m.LoadError):
            self.run_source(source, self.args())
        with database(self.stage()) as db:
            db.execute("INSERT INTO item VALUES(100,'tampered')")
        with self.assertRaisesRegex(m.LoadError, "checkpoint"):
            self.run_source(FakeSource(source.tables), self.args("--resume"))

    def test_quick_integrity_option(self):
        source = self.basic()
        self.run_source(source, self.args("--integrity", "quick", "--synchronous", "normal"))
        with database(self.output) as db:
            self.assertEqual(m.meta_get(db, "report")["integrity_check"], "quick")


class UnitTests(unittest.TestCase):
    def test_driver_probe_checks_actual_return_values(self):
        source = MagicMock()
        source.cursor.return_value.fetchone.return_value = (
            "12345678901234567890.123456789012345678", "-123.4567",
            "2026-10-07T12:34:56.1234567", "12:34:56.1234567",
            "2026-10-07T12:34:56.1234567+05:30",
            "01234567-89AB-CDEF-0123-456789ABCDEF", bytes((0,10,255)), "café")
        m.probe_source(source)
        source.cursor.return_value.close.assert_called_once()

    def test_driver_probe_rejects_fractional_precision_loss(self):
        source = MagicMock()
        source.cursor.return_value.fetchone.return_value = (
            "12345678901234567890.123456789012345678", "-123.4567",
            "2026-10-07T12:34:56.123456", "12:34:56.1234567",
            "2026-10-07T12:34:56.1234567+05:30",
            "01234567-89AB-CDEF-0123-456789ABCDEF", bytes((0,10,255)), "café")
        with self.assertRaisesRegex(m.LoadError, "type probe failed"):
            m.probe_source(source)
        source.cursor.return_value.close.assert_called_once()

    def test_identifier_escaping(self):
        self.assertEqual(m.qs("a]b"), "[a]]b]")
        self.assertEqual(m.qi('a"b'), '"a""b"')
        with self.assertRaises(m.LoadError):
            m.qi("\x00bad")

    def test_affinity_rules_and_strict_any(self):
        self.assertEqual(m.affinity("DECIMAL(38,4)"), "NUMERIC")
        self.assertEqual(m.affinity("VARCHAR(100)"), "TEXT")
        self.assertEqual(m.affinity("FLOATING POINT"), "INTEGER")
        self.assertEqual(m.affinity("ANY", True), "ANY")
        self.assertEqual(m.affinity("ANY", False), "NUMERIC")

    def test_decimal_numeric_destination_is_rejected(self):
        with self.assertRaisesRegex(m.LoadError, "risk coercion"):
            m.expression_for(column("x", "decimal"), {"name": "x", "type": "DECIMAL(38,4)"}, False, "text")

    def test_money_text_expression_preserves_four_places(self):
        expr, convert = m.expression_for(column("x", "money"), {"name": "x", "type": "TEXT"}, False, "text")
        self.assertEqual(expr, "CONVERT(varchar(100), CONVERT(decimal(19,4), [x]))")
        self.assertEqual(convert, "native")

    def test_temporal_projection_preserves_driver_bypass(self):
        expr, _ = m.expression_for(column("x", "datetimeoffset"), {"name": "x", "type": "TEXT"}, False, "text")
        self.assertIn("varchar(48)", expr)
        self.assertIn("127", expr)

    def test_scaled_integer_context_independent(self):
        self.assertEqual(m.scaled_integer("92233720368547758.07", 2), (1 << 63)-1)
        self.assertEqual(m.scaled_integer("-92233720368547758.08", 2), -(1 << 63))
        with self.assertRaises(m.LoadError):
            m.scaled_integer("92233720368547758.08", 2)
        with self.assertRaises(m.LoadError):
            m.scaled_integer("1.001", 2)
        with self.assertRaises(m.LoadError):
            m.scaled_integer("12345678901234567890123456789012345678", 0)

    def test_hash_is_typed_and_length_framed(self):
        self.assertNotEqual(m.row_hash(("ab", "c")), m.row_hash(("a", "bc")))
        self.assertNotEqual(m.row_hash((1,)), m.row_hash(("1",)))
        self.assertNotEqual(m.row_hash((b"1",)), m.row_hash(("1",)))
        self.assertEqual(m.row_hash((-0.0,)), m.row_hash((0.0,)))
        self.assertEqual(m.row_hash((True,)), m.row_hash((1,)))

    def test_no_clobber_atomic_publication(self):
        with tempfile.TemporaryDirectory() as folder:
            stage, output = Path(folder)/"stage", Path(folder)/"output"
            stage.write_bytes(b"new")
            output.write_bytes(b"existing")
            with self.assertRaises(m.LoadError):
                m.publish(stage, output, {})
            self.assertEqual(output.read_bytes(), b"existing")
            self.assertTrue(stage.exists())

    def test_process_lock_excludes_second_loader(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/"output.lock"
            with m.process_lock(path):
                with self.assertRaises(m.LoadError):
                    with m.process_lock(path):
                        pass

    def test_unsupported_type_rejected(self):
        with self.assertRaisesRegex(m.LoadError, "Unsupported"):
            m.expression_for(column("x", "geometry"), {"name": "x", "type": "BLOB"}, False, "text")


if __name__ == "__main__":
    unittest.main(verbosity=2)
