# SQL Server -> SQLite: data-only bulk loader

The application schema is yours. This tool copies data from one SQL Server database
into a new SQLite file using your **existing, empty SQLite database as a schema
template**. It does not translate your SQL scripts, create an application schema,
clone a SQL Server instance, or edit a Git repository.

The template is opened read-only and is never used as the output. A private staging
file is loaded and validated; only then is the new final filename published.
Existing output files are never overwritten.

## Files

- `mssql_to_sqlite.py`: standalone command-line loader.
- `test_loader.py`: local SQLite and controlled-source tests; no SQL Server needed.
- `mapping.example.json`: example table/column renaming and per-column decimal policy.
- `schema.example.sql`: illustrative SQLite schema corresponding to that mapping.
- `requirements.txt`: the one third-party dependency, pyodbc.
- `test_results.txt`: results from the local test run supplied with this package.

## Requirements and scope

Use Python 3.11+ and a supported Microsoft ODBC Driver for SQL Server, normally
ODBC Driver 18. SQLite 3.37+ is the functional minimum; **use a current, patched
SQLite runtime for production**, not merely the minimum. SQL Server 2016+ is the
metadata-compatibility target. This package has not been integration-tested against
a live SQL Server, Azure SQL, or a Windows ODBC installation in the authoring
session. Its local tests exercise real SQLite databases and controlled source
fixtures, not a real network or a power-loss simulator.

SQLite's documentation reports a WAL-reset race fixed in 3.51.3, with backports
including 3.44.6 and 3.50.7. This loader uses only one exclusive SQLite connection
and does not run a separate checkpointing thread, avoiding the documented
multi-connection race. Still deploy a patched build. The CLI warns for versions
without those known fixes. [1]

Check the runtime and installed drivers:

```powershell
python -c "import sqlite3; print(sqlite3.sqlite_version)"
python -m pip install -r requirements.txt
python -c "import pyodbc; print(pyodbc.drivers())"
```

Install the ODBC driver separately if it is missing. Installing pyodbc does not
install Microsoft's driver. Use your approved package mirror/installer, and freeze
exact tested package versions in your deployment environment. [2]

Use a protected **local** folder on NTFS, ext4, APFS, or another local filesystem
supporting hard links. Do not build the database on an SMB/NFS share or a
cloud-synchronized folder. WAL is not a multi-host network-filesystem protocol. [1]
The publication mechanism needs hard-link support to atomically create the final
name without overwriting a concurrently created file. Source data travels through
memory directly into SQLite: there is no CSV intermediary or third-party service.

A read-only SQL Server principal is recommended. The export sees only the data
that principal can read. Row-level security, masking, permissions, source views,
and filtering already defined in those views can affect what is exported. The
loader cannot prove that the account sees the entire underlying database.

## 1. Set the SQL Server connection string

PowerShell, Windows integrated authentication:

```powershell
$env:MSSQL_CONNECTION_STRING = "DRIVER={ODBC Driver 18 for SQL Server};SERVER=YOUR_SERVER;DATABASE=YOUR_DATABASE;Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=no;"
```

The script does not log this connection string. Use a certificate trusted by the
client, not a blanket certificate-validation bypass. For SQL authentication or
another approved authentication scheme, supply the corresponding ODBC connection
string through the same environment variable or your organization's secret
injection mechanism. Do not put a real password into source control.

Every new source connection performs a read-only constant-value probe that checks
actual SQL Server/ODBC handling of high-precision decimals, money, seven-place
fractional times, timezone offsets, GUIDs, Unicode, and binary values. A failed
probe stops before loading user data. This does not replace testing your actual
source column types and application semantics.

## 2. Supply your already-created schema

For example:

```text
C:\migration\schema.sqlite      <- your empty SQLite schema; left unchanged
C:\migration\snapshot.sqlite    <- new final database to create
```

All ordinary application tables in the template must be empty. A template with
seed/reference rows is rejected rather than appended to or cleared. Views in the
template are retained. Generated columns are not inserted; SQLite recomputes them.
Custom collations, extension-dependent schema objects, custom SQL functions, and
virtual/FTS tables require a separate integration path. Virtual/shadow tables are
explicitly rejected.

With no mapping file, the ordinary source table names in the selected source schema
(default `dbo`) must exactly match the template table names. Column names also match
exactly. Auto mode checks coverage instead of silently omitting source tables from
that selected schema. It does not automatically include other SQL Server schemas.

For renames, multiple source schemas, or a deliberate subset of source tables,
provide `--mapping mapping.json`. Every template table must still be mapped once.
The source and target schemas remain your responsibility; there is no schema
translation.

## 3. Preflight, then load

For a live source, the default is one SQL Server SNAPSHOT transaction spanning the
reads of all selected tables. `ALLOW_SNAPSHOT_ISOLATION` must already be ON. The
script checks it but never changes database settings. `READ_COMMITTED_SNAPSHOT`
alone is not a substitute for the explicit transaction-level SNAPSHOT used here.
Long-running snapshots retain row versions, so coordinate version-store capacity
and expected source load with the DBA. [3]

Preflight does not create a staging/output database or ingest table rows; it checks
the connection, constant-value type probe, table/column metadata, mappings, and
compilation of every zero-row SELECT projection:

```powershell
python .\mssql_to_sqlite.py --template "C:\migration\schema.sqlite" --output "C:\migration\snapshot.sqlite" --dry-run
```

Then run the copy with normal production durability:

```powershell
python .\mssql_to_sqlite.py --template "C:\migration\schema.sqlite" --output "C:\migration\snapshot.sqlite" --log-file "C:\migration\migration.log"
```

For the initial migration or a high-assurance copy, include value-hash verification:

```powershell
python .\mssql_to_sqlite.py --template "C:\migration\schema.sqlite" --output "C:\migration\snapshot.sqlite" --verify-hash --log-file "C:\migration\migration.log"
```

For mapped names add `--mapping .\mapping.json` to both preflight and load commands.
Choose an output name that does not already exist. The script deliberately does
not offer a switch that overwrites a live application database.

## 4. Resuming interrupted copies

There are two distinct source-consistency modes.

### A live source: `--source-mode snapshot` (default)

One connection holds one SQL Server SNAPSHOT transaction while reading the data.
No dirty-read/NOLOCK hints are used. If that connection is lost before all tables
are copied, that exact transaction snapshot cannot be resumed by reconnecting.
The loader **refuses partial-source resume**, rather than quietly mixing different
points in time. Start a new output filename for a fresh complete snapshot. [3]

If all source tables were already committed and only local validation/index
rebuilding/publication failed, `--resume` can finish those local steps without
reconnecting to SQL Server. The original template and configuration must match.

### A frozen source: `--source-mode static`

For a large job requiring restartability, use a fixed read-only restored backup,
a SQL Server database snapshot where available, or a database whose data and schema
are genuinely held unchanged for the entire operation **and every retry**.

```powershell
python .\mssql_to_sqlite.py --template "C:\migration\schema.sqlite" --output "C:\migration\snapshot.sqlite" --source-mode static --source-token "approved-backup-2026-10-07" --verify-hash
```

Resume with the **same command plus `--resume`**:

```powershell
python .\mssql_to_sqlite.py --template "C:\migration\schema.sqlite" --output "C:\migration\snapshot.sqlite" --source-mode static --source-token "approved-backup-2026-10-07" --verify-hash --resume
```

`--source-token` is an identifying label, **not evidence that the data is immutable**.
The script checks source identity and schema metadata and compares counts for
incomplete tables. It cannot detect every change to an allegedly frozen source.
It warns if the database is not marked read-only.

For a complete, single-column integer source primary key, static mode automatically
uses ordered keyset continuation:

```sql
SELECT ... FROM [dbo].[YourTable]
WHERE [YourPrimaryKey] > ?
ORDER BY [YourPrimaryKey];
```

Copied rows and their last-key checkpoint commit in the same SQLite transaction.
Negative keys and zero are supported. No OFFSET-based restart, INSERT OR IGNORE,
or duplicate-skipping approach is used.

When there is no eligible primary key, completed tables are retained, but an
**incomplete table is cleared and reloaded from its beginning**. Composite keys,
text/GUID keys, and arbitrary unique indexes do not get row-level continuation
in this implementation. Setting a table mapping's `"resume_key": null` also
chooses this behavior and avoids the ordering needed for keyset continuation.
Ordering by a nonclustered primary key can be more expensive than a simple scan;
this is a workload-specific speed/restartability tradeoff.

No automatic reconnection is attempted halfway through a live source transaction.
ODBC query timeout defaults to 300 seconds; increase `--query-timeout` for expensive
counts or long-running scans. Driver cancellation is requested on interruption,
but how promptly a blocked network call returns is driver/network-dependent.

## Table and column mappings

Example:

```json
{
  "tables": [
    {
      "source_schema": "dbo",
      "source_table": "Transactions",
      "target_table": "transactions",
      "columns": {
        "transaction_id": "TransactionID",
        "amount": "Amount",
        "occurred_at": "OccurredAt"
      },
      "decimal_modes": {"amount": "text"},
      "resume_key": "TransactionID"
    }
  ]
}
```

`columns` maps **SQLite target name -> SQL Server source name**. Columns not named
in the mapping still use identical names. Keys, schema names and table names are
quoted as identifiers; values use parameters. Arbitrary SQL expressions are not
accepted from the mapping file.

Optional fields:

| Field | Meaning |
|---|---|
| `ignore_source_columns` | Explicit list of source columns deliberately not copied. |
| `use_target_defaults` | Explicit list of target columns deliberately omitted so target defaults/NULL apply. Required columns without defaults and primary keys cannot be omitted. |
| `decimal_modes` | Per-target-column override: `text`, `scaled_integer`, or `real`. |
| `resume_key` | `auto` (default), the eligible single integer source PK name, or `null` for whole-table restart. Only used in static mode. |

Same-named generated target columns are treated as deliberately recomputed rather
than directly copied. Source columns omitted otherwise must be explicitly listed.
Renamed generated/defaulted columns and dropped source columns need explicit
mapping/omission declarations. The manifest records these choices.

## Exact values and supported source types

SQLite's declared `DECIMAL(38,10)` is **not** a fixed-precision decimal storage type.
Its NUMERIC affinity can coerce numeric strings into INTEGER or binary64 REAL,
losing decimal precision. This loader validates destination affinity before loading
rather than trusting the declared type's name. [4]

| Source | Default SQLite storage / handling |
|---|---|
| bigint/int/smallint/tinyint/bit | INTEGER, or compatible exact integer affinity. |
| decimal/numeric/money/smallmoney | Exact decimal text in TEXT; money first converted to decimal(19,4). |
| float/real | REAL; source values are already approximate. |
| character types | TEXT, including NULL versus empty string. |
| date/time/datetime/datetime2/smalldatetime/datetimeoffset | ISO-style TEXT, formatted in SQL Server rather than via Python's microsecond-limited datetime objects. |
| uniqueidentifier | 36-character TEXT. |
| binary/varbinary/image/timestamp/rowversion | BLOB; SQL Server timestamp is not a wall-clock date/time. |
| XML | SQL Server's serialized XML text; not a promise of original source-document byte identity. |

The SQL Server formatting conventions are based on Microsoft CAST/CONVERT
semantics. Do not truncate datetime strings to 19 or 23 characters when you need
seven-place fractional seconds or offsets. [5]

For decimal columns you intentionally redesigned:

- `text`: exact representation, the default; use TEXT. Ordinary SQLite numeric
  arithmetic and lexical sorting on these strings are not arbitrary-precision
  decimal operations. Application handling remains your responsibility.
- `scaled_integer`: exact integer at the **source column's declared scale**. For
  `decimal(...,2)`, `12.34` becomes `1234`. For MONEY (scale 4), `12.3400` becomes
  `123400`, not cents. Overflow outside signed 64-bit storage is rejected, never
  silently rounded. Use INTEGER and record the scale in your application.
- `real`: explicitly approximate conversion to a binary64 float. Use REAL. This is
  opt-in, not recommended as an unnoticed default for financial amounts.

Unsupported source types (for example sql_variant, spatial/CLR UDT types, or
always-encrypted columns) fail explicitly. For a reviewed spatial/UDT conversion,
expose appropriate built-in TEXT/BLOB columns in a SQL Server view and explicitly
map that view. This is not a generic encrypted-column export path. A view's
semantics, external databases, and nondeterministic expressions require separate
review; snapshot isolation does not turn a volatile function into a historical
stored value.

The application schema controls target constraints and collations. Those semantics
need not match SQL Server's. A uniqueness conflict fails the load; it is not skipped.
Nullable source columns are prohibited from feeding target primary keys to avoid
SQLite silently generating row IDs for NULL integer primary keys.

## Performance and durability

The transfer uses one source reader, a small bounded prefetch queue, and **one
SQLite writer**. It uses `fetchmany()` and parameterized `executemany()` in explicit
transactions. SQLite has one writer per database file; starting many SQLite writer
threads is not a general bulk-load accelerator. Batch transactions amortize commit
overhead. [1, 6, 7]

Defaults:

| Setting | Value |
|---|---:|
| Fetched rows per batch | 10,000 |
| Commit threshold | 100,000 rows, rounded up to a fetched-batch boundary |
| Prefetched batches | 2 |
| Suggested SQLite page-cache size | 256 MiB |
| Approximate WAL automatic-checkpoint threshold | 128 MiB |
| Journal mode while loading | WAL |
| Synchronous mode | FULL |
| Final database journal mode | DELETE, after checkpoint and close |
| Structural validation | Full integrity_check |
| Optional value hashing | Off unless `--verify-hash` is supplied |

The bounded queue limits batch count, not bytes. Peak memory also includes the
producer's fetched/converting batch, the writer's current batch, ODBC buffers,
Python objects, and SQLite's cache. For very large text/BLOB rows, begin with
`--batch-rows 100` or `1000`, not 10,000. A single field must still fit SQLite's
configured field-size limits and available memory. The WAL threshold is not a
hard cap: large transactions and index builds can exceed it. Keep free disk space
for the final database, WAL, temporary index-sort files, and ordinary filesystem
overhead. There is no universal source-to-SQLite size multiplier.

Non-unique secondary indexes are saved and rebuilt after loading. Primary-key and
unique constraints stay enforced. Use `--keep-indexes` to opt out of deferring those
secondary indexes. Temporary sorting is file-backed rather than forced into RAM.

The normal default is `--synchronous full`. An optional faster setting is:

```powershell
python .\mssql_to_sqlite.py --template "C:\migration\schema.sqlite" --output "C:\migration\snapshot.sqlite" --synchronous normal
```

In WAL mode, NORMAL trades power-loss durability of recent commits for lower sync
overhead; it does not mean the same thing as turning journaling off. The progress
checkpoint shares the same transaction as the rows, so they roll back together.
`journal_mode=OFF` and `synchronous=OFF` are deliberately not offered. Journaling
OFF can defeat rollback even on ordinary constraint errors. [8]

`--integrity quick` reduces final validation time but omits index-content and UNIQUE
checks covered by full integrity_check. Row counts and foreign-key checks still
run. Do not treat quick_check as the same assurance level. [8]

There is no universally fastest batch size or end-to-end migration method. This
implementation is a direct, auditable baseline that avoids a CSV serialize/parse
roundtrip. SQL Server's bcp can export efficiently, but its output still requires
correct SQLite ingestion and encoding, delimiter, NULL and binary handling; field
terminators embedded in data can be a correctness hazard. It is not automatically
a faster or safer end-to-end pipeline for every table. [9]

## Validation and audit information

Before publication the loader verifies source/fetched/target row counts, restores
saved indexes/triggers, compares the application schema to the template, checks
foreign keys, and runs the chosen SQLite structural check. It runs bounded planner
statistics maintenance and closes a checkpointed standalone file.

`--verify-hash` additionally hashes the **copied, converted source row values** and
re-reads the copied SQLite columns to compare an order-independent multiset digest.
It sums typed, length-framed row SHA-256 hashes modulo 2^256. This is a strong check
for accidental value changes, not an authenticity/signature mechanism or a proof
of semantic equivalence. Defaulted/generated target columns are excluded. An
intentional decimal-to-REAL conversion is verified after that conversion, not
against the original exact decimal. Hashing adds Python CPU cost and a full
destination scan. Matching row counts alone does not prove value equality.

Three small audit tables remain in the final file:

```text
__mssql_loader_meta
__mssql_loader_progress
__mssql_loader_objects
```

The manifest, source identity, mapping/conversion choices, committed progress and
final report are stored there. A convenient external report is also written to
`<output>.report.json`; failure to write that optional external report does not
invalidate the internally recorded report.

Foreign-key enforcement is a per-connection setting. The application must still
run `PRAGMA foreign_keys=ON` on **its own connections** when it needs enforcement.
The loader's setting is not a permanent database-wide switch. [8]

Template triggers are rejected by default. With `--defer-triggers`, they are saved,
removed only in staging, and restored afterwards. They **do not run** for imported
rows and are not replayed afterwards. Derived/audit tables that depend on trigger
execution need to be copied or rebuilt separately. No FTS trigger-based rebuilding
is implemented.

## Failure handling and operations

A normal interrupted load leaves `<output>.loading.sqlite` and transactional audit
state. Never open that staging database in your application, and do not modify its
rows, schema, or sidecar files. A `.lock` file is intentionally retained; the OS
releases the actual advisory lock when the process exits. Do not delete the lock
file while another loader may be running.

For a failed live-source partial copy, use a new output name and take a fresh
snapshot. For a static source, use the same configuration with `--resume`. If an
initialization was interrupted before a recognized stage existed, the script
leaves an `.init` file and asks you to inspect/remove it rather than guessing it is
safe to reuse. Do not manually delete active WAL/journal files as a recovery method.

Publication uses an atomic hard link after SQLite has checkpointed and closed the
file, then removes the staging name. A crash in that narrow interval can leave
both names referring to the same already-validated file. Do not run database
connections against both names. Inspect the internal validated state and retain
only the intended final name before use. Existing final files are never replaced.

Normal errors omit row values and the connection string. `--debug-errors` explicitly
enables raw exceptions/tracebacks, which may contain sensitive driver details or
source values. Store logs, SQLite files and reports under appropriate local ACLs.
The script does not add SQLite at-rest encryption.

## Testing

```powershell
python -m unittest -v test_loader.py
```

The supplied local run used Python 3.13.5 and SQLite 3.46.1, with the single-connection
staging design described above. The accompanying output records the exact test
count/results. Tests cover successful publication, index/schema preservation,
keyset resume including negative/zero keys, table-level restart, transaction
rollback, duplicate rejection, source-count/config changes, live-snapshot restart
refusal, offline finalization, foreign-key failures, trigger deferral, exact decimal
conversion, Unicode/NULL/empty/BLOB values, precision-preserving supplied temporal
strings, hash detection, and refusing to overwrite an output file.

The tests do not establish real SQL Server throughput, real ODBC cancellation
behavior, SQL Server isolation under concurrent load, or crash/power-loss durability
on your actual storage. Perform the provided read-only preflight and a representative
migration against your actual SQL Server/driver, then validate application queries
before deployment. No invented production throughput claim is made.

## Primary references

[1] SQLite, Write-Ahead Logging (including the 2026 WAL-reset bug and patched versions):
`https://www.sqlite.org/wal.html`

[2] Microsoft, Download ODBC Driver for SQL Server:
`https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server`

[3] Microsoft, SET TRANSACTION ISOLATION LEVEL and Snapshot Isolation:
`https://learn.microsoft.com/en-us/sql/t-sql/statements/set-transaction-isolation-level-transact-sql`
`https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/sql/snapshot-isolation-in-sql-server`

[4] SQLite, Datatypes In SQLite:
`https://www.sqlite.org/datatype3.html`

[5] Microsoft, CAST and CONVERT:
`https://learn.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql`

[6] Python, sqlite3 DB-API interface:
`https://docs.python.org/3/library/sqlite3.html`

[7] pyodbc, Cursor and Connection documentation; SQLite insertion/transaction guidance:
`https://github.com/mkleehammer/pyodbc/wiki/Cursor`
`https://github.com/mkleehammer/pyodbc/wiki/Connection`
`https://www.sqlite.org/faq.html#q19`

[8] SQLite, PRAGMA statements and conflict handling:
`https://www.sqlite.org/pragma.html`
`https://www.sqlite.org/lang_conflict.html`

[9] Microsoft, bcp utility and field/row terminators:
`https://learn.microsoft.com/en-us/sql/tools/bcp/bcp-utility`
`https://learn.microsoft.com/en-us/sql/relational-databases/import-export/specify-field-and-row-terminators-sql-server`
