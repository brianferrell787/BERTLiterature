#!/usr/bin/env python3
"""Data-only SQL Server -> pre-created SQLite schema, Python 3.11+.

See README.md for source consistency, mappings, supported types and deployment.
Only third-party dependency: pyodbc (imported lazily; tests need no SQL Server).
Never run an application against *.loading.sqlite. Use a protected local disk.
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import decimal
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import queue
import re
import sqlite3
import struct
import sys
import threading
import time
from typing import Any, Iterable, Iterator

VERSION = "1.0.0"
PREFIX = "__mssql_loader_"
META = PREFIX + "meta"
PROGRESS = PREFIX + "progress"
OBJECTS = PREFIX + "objects"
MODULUS = 1 << 256
LOG = logging.getLogger("mssql_to_sqlite")
INTEGER_TYPES = {"bigint", "int", "smallint", "tinyint", "bit"}
DECIMAL_TYPES = {"decimal", "numeric", "money", "smallmoney"}
TEXT_TYPES = {"char", "varchar", "nchar", "nvarchar", "text", "ntext"}
BINARY_TYPES = {"binary", "varbinary", "image", "timestamp", "rowversion"}
TEMPORAL_TYPES = {"date", "time", "datetime", "datetime2", "smalldatetime", "datetimeoffset"}


class LoadError(RuntimeError):
    """An actionable, value-redacted migration failure."""


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def qi(name: str) -> str:
    """Quote a SQLite identifier, not a SQL literal."""
    if not isinstance(name, str) or not name or "\x00" in name:
        raise LoadError("Invalid SQLite identifier.")
    return '"' + name.replace('"', '""') + '"'


def qs(name: str) -> str:
    """Quote one SQL Server identifier component."""
    if not isinstance(name, str) or not name or "\x00" in name:
        raise LoadError("Invalid SQL Server identifier.")
    return "[" + name.replace("]", "]]") + "]"


def qualified(plan: dict) -> str:
    return qs(plan["source_schema"]) + "." + qs(plan["source_table"])


def error_label(exc: BaseException) -> str:
    code = getattr(exc, "sqlite_errorname", None)
    if not code and getattr(exc, "args", None):
        first = str(exc.args[0])
        if re.fullmatch(r"[A-Z0-9]{5}", first):
            code = first
    return type(exc).__name__ + (f" ({code})" if code else "")


@contextlib.contextmanager
def transaction(db: sqlite3.Connection) -> Iterator[None]:
    db.execute("BEGIN IMMEDIATE")
    try:
        yield
        db.commit()
    except BaseException:
        db.rollback()
        raise


@contextlib.contextmanager
def process_lock(path: Path) -> Iterator[None]:
    """OS-released advisory lock; the small lock file intentionally persists."""
    with open(path, "a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise LoadError("Another loader holds this output's lock.") from None
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def fsync_directory(path: Path) -> None:
    if os.name != "nt":
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def read_only_sqlite(path: Path) -> sqlite3.Connection:
    if not path.is_file():
        raise LoadError(f"SQLite template does not exist: {path}")
    return sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, isolation_level=None)


def schema_fingerprint(db: sqlite3.Connection) -> str:
    rows = db.execute(
        "SELECT type,name,tbl_name,sql FROM sqlite_schema "
        "WHERE name NOT GLOB 'sqlite_*' AND name NOT GLOB ? ORDER BY type,name",
        (PREFIX + "*",),
    ).fetchall()
    return digest(rows)


def inspect_template(db: sqlite3.Connection, defer_triggers: bool) -> list[dict]:
    # table_list distinguishes virtual tables and their shadow tables correctly.
    tables = []
    for row in db.execute("PRAGMA table_list"):
        schema, name, kind, _, _, strict = row[:6]
        if schema != "main" or name.startswith("sqlite_"):
            continue
        if name.startswith(PREFIX):
            raise LoadError(f"Reserved table prefix in template: {PREFIX}")
        if kind in {"virtual", "shadow"}:
            raise LoadError("Virtual/FTS/shadow tables need a separate rebuild; not supported by this loader.")
        if kind != "table":
            continue
        if db.execute(f"SELECT 1 FROM {qi(name)} LIMIT 1").fetchone():
            raise LoadError(f"Template table {name!r} is not empty. Supply a schema-only database.")
        columns = [dict(zip(("cid", "name", "type", "notnull", "default", "pk", "hidden"), r))
                   for r in db.execute("SELECT * FROM pragma_table_xinfo(?)", (name,))]
        tables.append({"name": name, "strict": bool(strict), "columns": columns})
    if not tables:
        raise LoadError("No ordinary, pre-created tables found in the template.")
    if not defer_triggers and db.execute("SELECT 1 FROM sqlite_schema WHERE type='trigger' LIMIT 1").fetchone():
        raise LoadError("Template contains triggers. Create them later, or explicitly use --defer-triggers.")
    return sorted(tables, key=lambda t: t["name"])


def affinity(declared: str, strict: bool = False) -> str:
    text = declared.upper()
    if strict and text == "ANY":
        return "ANY"
    if "INT" in text:
        return "INTEGER"
    if any(part in text for part in ("CHAR", "CLOB", "TEXT")):
        return "TEXT"
    if "BLOB" in text or not text:
        return "BLOB"
    if any(part in text for part in ("REAL", "FLOA", "DOUB")):
        return "REAL"
    return "NUMERIC"


def expression_for(source: dict, target: dict, strict: bool, decimal_mode: str) -> tuple[str, str]:
    """Push lossless formatting into SQL Server; return expression and Python conversion."""
    name, typ = source["name"], source["type"].lower()
    col = qs(name)
    aff = affinity(target["type"], strict)
    convert = "native"
    if source.get("encrypted"):
        raise LoadError(f"Encrypted source column {name!r} requires a separately reviewed export path.")
    if typ in INTEGER_TYPES:
        allowed, expression = {"INTEGER", "NUMERIC", "ANY"}, col
    elif typ in DECIMAL_TYPES:
        if decimal_mode == "real":
            allowed, expression = {"REAL", "ANY"}, f"CONVERT(float, {col})"
        else:
            # MONEY -> decimal first, avoiding MONEY's default two-place string rendering.
            inner = f"CONVERT(decimal(19,4), {col})" if typ in {"money", "smallmoney"} else col
            expression = f"CONVERT(varchar(100), {inner})"
            if decimal_mode == "text":
                allowed = {"TEXT", "ANY"}
            elif decimal_mode == "scaled_integer":
                allowed, convert = {"INTEGER", "ANY"}, "scaled_integer"
            else:
                raise LoadError(f"Unknown decimal mode: {decimal_mode!r}")
    elif typ in {"real", "float"}:
        allowed, expression = {"REAL", "ANY"}, col
    elif typ in TEXT_TYPES:
        allowed, expression = {"TEXT", "ANY"}, col
    elif typ == "xml":
        allowed, expression = {"TEXT", "ANY"}, f"CONVERT(nvarchar(max), {col})"
    elif typ == "uniqueidentifier":
        allowed, expression = {"TEXT", "ANY"}, f"CONVERT(char(36), {col})"
    elif typ in TEMPORAL_TYPES:
        allowed = {"TEXT", "ANY"}
        if typ == "date":
            expression = f"CONVERT(char(10), {col}, 23)"
        else:
            style = 127 if typ == "datetimeoffset" else 126
            expression = f"CONVERT(varchar(48), {col}, {style})"
    elif typ in BINARY_TYPES:
        allowed, expression = {"BLOB", "ANY"}, col
    else:
        raise LoadError(f"Unsupported source type {typ!r} for column {name!r}; expose a reviewed TEXT/BLOB conversion in a source view.")
    if aff not in allowed:
        raise LoadError(f"Column {name!r} ({typ}) -> {target['name']!r} ({target['type']}) would risk coercion. "
                        f"Required target affinity: {', '.join(sorted(allowed))}. Decimal policy: {decimal_mode}.")
    return expression, convert


def scaled_integer(value: str, scale: int) -> int:
    # as_integer_ratio is exact and does NOT depend on Decimal's context precision.
    number = decimal.Decimal(value)
    if not number.is_finite():
        raise LoadError("Non-finite decimal encountered.")
    numerator, denominator = number.as_integer_ratio()
    result, remainder = divmod(numerator * (10 ** scale), denominator)
    if remainder or not -(1 << 63) <= result < (1 << 63):
        raise LoadError("Scaled decimal cannot be represented exactly as a signed 64-bit SQLite integer.")
    return result


def row_hash(row: Iterable[Any]) -> int:
    """Typed, length-framed SHA-256 per row, for an optional unordered multiset check."""
    h = hashlib.sha256()
    for value in row:
        if value is None:
            tag, data = b"N", b""
        elif isinstance(value, (int, bool)):
            tag, data = b"I", str(int(value)).encode("ascii")
        elif isinstance(value, float):
            if not math.isfinite(value):
                raise LoadError("Non-finite floating-point value encountered.")
            # SQLite need not preserve the sign of floating-point zero.
            tag, data = b"F", struct.pack(">d", 0.0 if value == 0.0 else value)
        elif isinstance(value, str):
            tag, data = b"T", value.encode("utf-8")
        elif isinstance(value, (bytes, bytearray, memoryview)):
            tag, data = b"B", bytes(value)
        else:
            raise LoadError(f"Unexpected value type for hashing: {type(value).__name__}")
        h.update(tag)
        h.update(len(data).to_bytes(8, "big"))
        h.update(data)
    return int.from_bytes(h.digest(), "big")


def convert_batch(rows: list, plan: dict, verify_hash: bool) -> tuple[list[tuple], int]:
    conversions = [(i, c["scale"]) for i, c in enumerate(plan["columns"]) if c["convert"] == "scaled_integer"]
    result, total = [], 0
    for raw in rows:
        if conversions:
            converted = list(raw)
            for index, scale in conversions:
                if converted[index] is not None:
                    converted[index] = scaled_integer(converted[index], scale)
            row = tuple(converted)
        else:
            row = tuple(raw)
        result.append(row)
        if verify_hash:
            total = (total + row_hash(row)) % MODULUS
    return result, total


def fetch_metadata(source: Any, schema: str, table: str) -> tuple[list[dict], list[str]]:
    cursor = source.cursor()
    try:
        cursor.execute("""
            SELECT c.name, COALESCE(bt.name, ut.name), c.precision, c.scale,
                   c.is_nullable, c.encryption_type
            FROM sys.columns AS c
            JOIN sys.objects AS o ON o.object_id=c.object_id
            JOIN sys.schemas AS s ON s.schema_id=o.schema_id
            JOIN sys.types AS ut ON ut.user_type_id=c.user_type_id
            LEFT JOIN sys.types AS bt ON bt.user_type_id=c.system_type_id
                                     AND bt.system_type_id=bt.user_type_id
            WHERE s.name=? AND o.name=? AND o.type IN ('U','V')
            ORDER BY c.column_id
        """, schema, table)
        columns = [dict(zip(("name", "type", "precision", "scale", "nullable", "encrypted"), row))
                   for row in cursor.fetchall()]
        if not columns:
            raise LoadError(f"Source table/view not found or not visible: {schema}.{table}")
        cursor.execute("""
            SELECT c.name
            FROM sys.indexes AS i
            JOIN sys.objects AS o ON o.object_id=i.object_id
            JOIN sys.schemas AS s ON s.schema_id=o.schema_id
            JOIN sys.index_columns AS ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id
            JOIN sys.columns AS c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
            WHERE s.name=? AND o.name=? AND i.is_primary_key=1
                  AND i.is_disabled=0 AND ic.key_ordinal>0
            ORDER BY ic.key_ordinal
        """, schema, table)
        primary_key = [r[0] for r in cursor.fetchall()]
        return columns, primary_key
    finally:
        cursor.close()


def build_plan(source: Any, targets: list[dict], config: dict, args: argparse.Namespace) -> list[dict]:
    unknown = set(config) - {"tables"}
    if unknown:
        raise LoadError(f"Unknown mapping-file options: {sorted(unknown)}")
    target_names = {t["name"] for t in targets}
    explicit = config.get("tables")
    if explicit is None:
        items = [{"target_table": t["name"], "source_schema": args.source_schema,
                  "source_table": t["name"]} for t in targets]
        cur = source.cursor()
        try:
            cur.execute("SELECT t.name FROM sys.tables t JOIN sys.schemas s ON t.schema_id=s.schema_id "
                        "WHERE s.name=? AND t.is_ms_shipped=0", args.source_schema)
            source_names = {row[0] for row in cur.fetchall()}
        finally:
            cur.close()
        # Auto mode intentionally demands exact names. Use a mapping file for renames/subsets.
        if source_names != target_names:
            raise LoadError("Auto mode requires identical table names in the selected SQL Server schema and template. "
                            f"Missing in template: {sorted(source_names-target_names)}; "
                            f"missing in source: {sorted(target_names-source_names)}. Use --mapping for an explicit selection.")
    else:
        if not isinstance(explicit, list) or not explicit:
            raise LoadError("'tables' must be a nonempty list.")
        items = explicit
        mapped = [item.get("target_table") for item in items]
        if len(mapped) != len(set(mapped)) or set(mapped) != target_names:
            raise LoadError("Explicit mapping must cover every template table exactly once.")
    targets_by_name = {t["name"]: t for t in targets}
    plans = []
    for item in items:
        allowed = {"source_schema", "source_table", "target_table", "columns", "ignore_source_columns",
                   "use_target_defaults", "decimal_modes", "resume_key"}
        if set(item) - allowed:
            raise LoadError(f"Unknown table mapping options: {sorted(set(item)-allowed)}")
        target = targets_by_name[item["target_table"]]
        schema = item.get("source_schema", args.source_schema)
        table = item.get("source_table", target["name"])
        source_columns, pk = fetch_metadata(source, schema, table)
        by_name = {c["name"]: c for c in source_columns}
        mappings = item.get("columns", {})
        defaults = set(item.get("use_target_defaults", []))
        ignored = set(item.get("ignore_source_columns", []))
        decimal_modes = item.get("decimal_modes", {})
        regular = [c for c in target["columns"] if c["hidden"] == 0]
        names = {c["name"] for c in regular}
        if set(mappings) - names or defaults - names or set(decimal_modes) - names or ignored - set(by_name):
            raise LoadError(f"Unknown column in mapping for {target['name']!r}.")
        if defaults & set(mappings):
            raise LoadError("A target column cannot be both mapped and defaulted.")
        columns, used = [], set()
        for dest in regular:
            name = dest["name"]
            if name in defaults:
                if dest["pk"] or (dest["notnull"] and dest["default"] is None):
                    raise LoadError(f"Cannot omit required target column: {target['name']}.{name}")
                continue
            source_name = mappings.get(name, name)
            if source_name not in by_name:
                raise LoadError(f"Source column {source_name!r} is missing for {target['name']}.{name}.")
            src = by_name[source_name]
            if dest["pk"] and src["nullable"]:
                raise LoadError(f"Nullable source column {source_name!r} cannot feed a target primary key; this could generate unintended row IDs.")
            policy = decimal_modes.get(name, args.decimal_mode)
            if policy not in {"text", "real", "scaled_integer"}:
                raise LoadError(f"Unknown decimal mode: {policy!r}")
            expression, convert = expression_for(src, dest, target["strict"], policy)
            columns.append({"source": source_name, "target": name, "source_type": src["type"],
                            "precision": src["precision"], "scale": 4 if src["type"] in {"money", "smallmoney"} else src["scale"],
                            "nullable": bool(src["nullable"]), "target_type": dest["type"],
                            "expression": expression, "convert": convert, "decimal_mode": policy})
            used.add(source_name)
        # Same-named generated destination columns are deliberately recomputed, not inserted.
        generated = {c["name"] for c in target["columns"] if c["hidden"] in {2, 3}}
        if used & ignored:
            raise LoadError("A source column cannot be both used and ignored.")
        uncovered = set(by_name) - used - ignored - generated
        if uncovered:
            raise LoadError(f"Unmapped source columns in {schema}.{table}: {sorted(uncovered)}. "
                            "Explicitly list deliberate omissions in ignore_source_columns.")
        if not columns:
            raise LoadError("At least one copied column per table is required.")
        key = None
        requested_key = item.get("resume_key", "auto")
        if args.source_mode == "static" and requested_key is not None:
            if len(pk) == 1 and pk[0] in used and by_name[pk[0]]["type"] in INTEGER_TYPES - {"bit"}:
                key = pk[0]
            if requested_key != "auto" and requested_key != key:
                raise LoadError("resume_key must be the complete, single-column integer source primary key, or null.")
        key_index = next((i for i, c in enumerate(columns) if c["source"] == key), None)
        plan = {"source_schema": schema, "source_table": table, "target_table": target["name"],
                "columns": columns, "resume_key": key, "key_index": key_index,
                "source_columns": source_columns, "source_primary_key": pk,
                "ignored_source_columns": sorted(ignored), "defaulted_target_columns": sorted(defaults),
                "generated_target_columns": sorted(generated)}
        plans.append(plan)
    return plans


def probe_source(source: Any) -> None:
    """Read-only constants: verify actual ODBC transport and exact SQL formatting."""
    cursor = source.cursor()
    try:
        cursor.execute("""
            SELECT
              CONVERT(varchar(100), CAST('12345678901234567890.123456789012345678' AS decimal(38,18))),
              CONVERT(varchar(100), CONVERT(decimal(19,4), CAST('-123.4567' AS money))),
              CONVERT(varchar(48), CAST('2026-10-07T12:34:56.1234567' AS datetime2(7)), 126),
              CONVERT(varchar(48), CAST('12:34:56.1234567' AS time(7)), 126),
              CONVERT(varchar(48), CAST('2026-10-07T12:34:56.1234567+05:30' AS datetimeoffset(7)), 127),
              CONVERT(char(36), CAST('01234567-89AB-CDEF-0123-456789ABCDEF' AS uniqueidentifier)),
              CONVERT(varbinary(max), 0x000AFF), CAST(N'café' AS nvarchar(10))
        """)
        row = tuple(cursor.fetchone())
        expected = ("12345678901234567890.123456789012345678", "-123.4567",
                    "2026-10-07T12:34:56.1234567", "12:34:56.1234567",
                    "2026-10-07T12:34:56.1234567+05:30",
                    "01234567-89ab-cdef-0123-456789abcdef", bytes((0, 10, 255)), "café")
        actual = row[:5] + (row[5].lower(),) + row[6:]
        if actual != expected:
            raise LoadError("Read-only SQL Server type probe failed: driver/formatting did not preserve the expected decimal, temporal, Unicode, GUID or binary values. No user data was loaded.")
        LOG.info("Read-only SQL Server type/driver probe passed")
    finally:
        cursor.close()


def compile_projections(source: Any, plans: list[dict]) -> None:
    """Compile every projection without reading table rows or changing source data."""
    cursor = source.cursor()
    try:
        for plan in plans:
            expressions = ",".join(c["expression"] for c in plan["columns"])
            cursor.execute(f"SELECT TOP (0) {expressions} FROM {qualified(plan)}")
            # Drain the zero-row result before submitting another statement.
            cursor.fetchall()
    finally:
        cursor.close()


def connect_source(args: argparse.Namespace) -> tuple[Any, dict]:
    connection_string = os.environ.get(args.connection_env)
    if not connection_string:
        raise LoadError(f"Set environment variable {args.connection_env} to the SQL Server ODBC connection string.")
    try:
        import pyodbc
    except ImportError:
        raise LoadError("Install pyodbc: python -m pip install pyodbc") from None
    pyodbc.pooling = False
    source = pyodbc.connect(connection_string, autocommit=True, timeout=args.login_timeout)
    try:
        source.timeout = args.query_timeout
        probe_source(source)
        cur = source.cursor()
        try:
            cur.execute("SET NOCOUNT ON; SET XACT_ABORT ON;")
            cur.execute("""
                SELECT CONVERT(nvarchar(128), SERVERPROPERTY('ServerName')), DB_NAME(),
                       CONVERT(varchar(40), create_date, 126), is_read_only, snapshot_isolation_state_desc
                FROM sys.databases WHERE database_id=DB_ID()
            """)
            row = cur.fetchone()
            if not row:
                raise LoadError("Cannot inspect the connected SQL Server database.")
            identity = {"server": row[0], "database": row[1], "database_created": row[2],
                        "read_only": bool(row[3]), "source_mode": args.source_mode,
                        "source_token": args.source_token}
            if args.source_mode == "snapshot":
                if row[4] != "ON":
                    raise LoadError("SQL Server ALLOW_SNAPSHOT_ISOLATION is not ON. Ask the DBA, "
                                    "or use --source-mode static only against a genuinely unchanged source.")
                cur.execute("SET TRANSACTION ISOLATION LEVEL SNAPSHOT; BEGIN TRANSACTION;")
            else:
                cur.execute("SET TRANSACTION ISOLATION LEVEL READ COMMITTED;")
                if not identity["read_only"]:
                    LOG.warning("STATIC SOURCE IS NOT MARKED READ_ONLY: you must prevent all data and schema changes, including across resumes.")
            return source, identity
        finally:
            cur.close()
    except BaseException:
        source.close()
        raise


def close_source(source: Any) -> None:
    with contextlib.suppress(Exception):
        cur = source.cursor()
        try:
            cur.execute("IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;")
        finally:
            cur.close()
    with contextlib.suppress(Exception):
        source.close()


def meta_set(db: sqlite3.Connection, key: str, value: Any) -> None:
    db.execute(f"INSERT INTO {qi(META)}(key,value) VALUES(?,?) "
               "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, canonical_json(value)))


def meta_get(db: sqlite3.Connection, key: str) -> Any:
    row = db.execute(f"SELECT value FROM {qi(META)} WHERE key=?", (key,)).fetchone()
    if row is None:
        raise LoadError(f"Missing loader metadata: {key}")
    return json.loads(row[0])


def progress_rows(db: sqlite3.Connection) -> dict[str, dict]:
    return {r[0]: dict(zip(("table", "status", "rows", "last_key", "expected", "hash_sum"), r))
            for r in db.execute(f"SELECT table_name,status,row_count,last_key,expected_count,hash_sum FROM {qi(PROGRESS)}")}


def configure_destination(db: sqlite3.Connection, args: argparse.Namespace) -> None:
    # This is a private staging database, not an in-service application database.
    db.execute("PRAGMA foreign_keys=OFF")
    db.execute("PRAGMA locking_mode=EXCLUSIVE")
    mode = db.execute("PRAGMA journal_mode=WAL").fetchone()[0]
    if mode.lower() != "wal":
        raise LoadError("Could not enable WAL for the staging database.")
    db.execute(f"PRAGMA synchronous={args.synchronous.upper()}")
    db.execute(f"PRAGMA cache_size={-args.cache_mib * 1024}")
    # File-backed temporary storage avoids forcing a huge index sort into RAM.
    db.execute("PRAGMA temp_store=FILE")
    page_size = db.execute("PRAGMA page_size").fetchone()[0]
    db.execute(f"PRAGMA wal_autocheckpoint={max(1, args.wal_mib * 1024 * 1024 // page_size)}")
    db.execute(f"PRAGMA journal_size_limit={args.wal_mib * 1024 * 1024}")


def initialize_stage(template_db: sqlite3.Connection, stage: Path, manifest: dict,
                     args: argparse.Namespace) -> None:
    initial = Path(str(stage) + ".init")
    if initial.exists():
        raise LoadError(f"Unfinished initialization exists: {initial}. Inspect/remove it before starting again.")
    initial.touch(mode=0o600, exist_ok=False)
    db = sqlite3.connect(initial, isolation_level=None)
    try:
        template_db.backup(db)
        db.execute("PRAGMA journal_mode=DELETE")
        db.execute("PRAGMA synchronous=EXTRA")
        with transaction(db):
            db.execute(f"CREATE TABLE {qi(META)} (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            db.execute(f"""CREATE TABLE {qi(PROGRESS)} (
                table_name TEXT PRIMARY KEY, status TEXT NOT NULL,
                row_count INTEGER NOT NULL DEFAULT 0, last_key INTEGER,
                expected_count INTEGER, hash_sum TEXT NOT NULL DEFAULT '0')""")
            db.execute(f"""CREATE TABLE {qi(OBJECTS)} (
                name TEXT PRIMARY KEY, kind TEXT NOT NULL, ddl TEXT NOT NULL,
                restored INTEGER NOT NULL DEFAULT 0)""")
            meta_set(db, "manifest", manifest)
            meta_set(db, "manifest_hash", digest(manifest))
            meta_set(db, "created_utc", utcnow())
            meta_set(db, "state", "loading")
            for plan in manifest["tables"]:
                name = plan["target_table"]
                db.execute(f"INSERT INTO {qi(PROGRESS)}(table_name,status) VALUES(?,'pending')", (name,))
                if not args.keep_indexes:
                    indexes = db.execute("SELECT * FROM pragma_index_list(?)", (name,)).fetchall()
                    for idx in indexes:
                        if not idx[2] and idx[3] == "c":
                            ddl = db.execute("SELECT sql FROM sqlite_schema WHERE type='index' AND name=?", (idx[1],)).fetchone()[0]
                            db.execute(f"INSERT INTO {qi(OBJECTS)}(name,kind,ddl) VALUES(?,'index',?)", (idx[1], ddl))
                            db.execute(f"DROP INDEX {qi(idx[1])}")
            if args.defer_triggers:
                for name, ddl in db.execute("SELECT name,sql FROM sqlite_schema WHERE type='trigger'").fetchall():
                    db.execute(f"INSERT INTO {qi(OBJECTS)}(name,kind,ddl) VALUES(?,'trigger',?)", (name, ddl))
                    db.execute(f"DROP TRIGGER {qi(name)}")
            if db.execute("SELECT 1 FROM sqlite_schema WHERE name='sqlite_sequence'").fetchone():
                db.execute("DELETE FROM sqlite_sequence")
    finally:
        db.close()
    os.rename(initial, stage)
    fsync_directory(stage.parent)


class SourceReader:
    """One SQL Server connection/reader; a bounded queue overlaps read and write I/O.

    After start(), this worker owns the source connection. The writer thread never
    executes SQL on it. Only ODBC cancellation is requested cross-thread.
    """
    def __init__(self, source: Any, jobs: list[tuple[dict, dict]], args: argparse.Namespace):
        self.source, self.jobs, self.args = source, jobs, args
        self.queue: queue.Queue = queue.Queue(maxsize=args.prefetch_batches)
        self.stop = threading.Event()
        self.cursor: Any = None
        self.cursor_lock = threading.Lock()
        self.thread = threading.Thread(target=self._run, name="sql-server-reader", daemon=True)

    def _put(self, event: tuple) -> bool:
        while not self.stop.is_set():
            try:
                self.queue.put(event, timeout=0.2)
                return True
            except queue.Full:
                pass
        return False

    def _run(self) -> None:
        try:
            self.cursor = self.source.cursor()
            self.cursor.arraysize = self.args.batch_rows
            for plan, state in self.jobs:
                if self.stop.is_set():
                    return
                name = plan["target_table"]
                self.cursor.execute(f"SELECT COUNT_BIG(*) FROM {qualified(plan)}")
                expected = int(self.cursor.fetchone()[0])
                if state["expected"] is not None and state["expected"] != expected:
                    raise LoadError(f"Source row count changed for {name!r}; resume refused.")
                if not self._put(("start", plan, expected)):
                    return
                selected = ",".join(c["expression"] for c in plan["columns"])
                sql = f"SELECT {selected} FROM {qualified(plan)}"
                params = []
                if plan["resume_key"]:
                    if state["last_key"] is not None:
                        sql += f" WHERE {qs(plan['resume_key'])} > ?"
                        params.append(state["last_key"])
                    sql += f" ORDER BY {qs(plan['resume_key'])}"
                self.cursor.execute(sql, *params)
                previous = state["last_key"]
                while not self.stop.is_set():
                    raw = self.cursor.fetchmany(self.args.batch_rows)
                    if not raw:
                        break
                    rows, batch_hash = convert_batch(raw, plan, self.args.verify_hash)
                    del raw
                    key = None
                    if plan["resume_key"]:
                        index = plan["key_index"]
                        # A schema-verified primary key should be strictly increasing.
                        for row in rows:
                            key = row[index]
                            if not isinstance(key, int) or (previous is not None and key <= previous):
                                raise LoadError(f"Invalid resume-key ordering for {name!r}.")
                            previous = key
                    if not self._put(("batch", name, rows, key, batch_hash)):
                        return
                if self.stop.is_set():
                    return
                if not self._put(("end", name)):
                    return
            self._put(("done",))
        except BaseException as exc:
            LOG.debug("Source reader failure", exc_info=True)
            self._put(("error", exc if isinstance(exc, LoadError) else LoadError(f"SQL Server reader failed: {error_label(exc)}. Use --debug-errors for driver details.")))
        finally:
            with self.cursor_lock:
                if self.cursor is not None:
                    with contextlib.suppress(Exception):
                        self.cursor.close()
                self.cursor = None
            close_source(self.source)

    def __enter__(self) -> "SourceReader":
        self.thread.start()
        return self

    def __iter__(self) -> Iterator[tuple]:
        while True:
            try:
                event = self.queue.get(timeout=0.5)
            except queue.Empty:
                if not self.thread.is_alive():
                    raise LoadError("Source reader stopped without a completion event.")
                continue
            if event[0] == "error":
                raise event[1]
            if event[0] == "done":
                return
            yield event

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.stop.set()
        if exc_type:
            with self.cursor_lock:
                if self.cursor is not None:
                    with contextlib.suppress(Exception):
                        self.cursor.cancel()
        self.thread.join(timeout=5)
        if self.thread.is_alive():
            LOG.warning("ODBC reader has not exited after cancellation; its daemon thread will end with this process. No source reconnect attempted.")


def check_checkpoint(db: sqlite3.Connection, plan: dict, state: dict) -> dict:
    name = plan["target_table"]
    actual = db.execute(f"SELECT COUNT(*) FROM {qi(name)}").fetchone()[0]
    if actual != state["rows"]:
        raise LoadError(f"Staging row count no longer matches checkpoint for {name!r}. Do not modify staging files.")
    if state["status"] != "complete" and state["rows"] and not plan["resume_key"]:
        # No stable one-column integer key: repeat only this incomplete table.
        LOG.warning("Restarting incomplete table %s from row zero (no eligible resume key).", name)
        with transaction(db):
            db.execute(f"DELETE FROM {qi(name)}")
            db.execute(f"UPDATE {qi(PROGRESS)} SET row_count=0,last_key=NULL,hash_sum='0',status='pending' WHERE table_name=?", (name,))
        state = dict(state, rows=0, last_key=None, hash_sum="0", status="pending")
    return state


def checkpoint(db: sqlite3.Connection, name: str, rows: int, key: int | None, hash_sum: int, status: str) -> None:
    db.execute(f"UPDATE {qi(PROGRESS)} SET row_count=?,last_key=?,hash_sum=?,status=? WHERE table_name=?",
               (rows, key, format(hash_sum, "x"), status, name))
    db.commit()


def consume(db: sqlite3.Connection, reader: Iterable[tuple], states: dict[str, dict], args: argparse.Namespace) -> None:
    current, insert_sql, rows, key, hash_sum, pending, expected = None, "", 0, None, 0, 0, 0
    start_time, log_time = time.monotonic(), time.monotonic()
    run_rows = 0
    try:
        for event in reader:
            kind = event[0]
            if kind == "start":
                if current is not None:
                    raise LoadError("Internal reader/writer table-order mismatch.")
                plan, expected = event[1:]
                current = plan["target_table"]
                state = states[current]
                rows, key, hash_sum = state["rows"], state["last_key"], int(state["hash_sum"], 16)
                names = ",".join(qi(c["target"]) for c in plan["columns"])
                params = ",".join("?" for _ in plan["columns"])
                # OR ABORT overrides schema-level IGNORE/REPLACE conflict policies.
                insert_sql = f"INSERT OR ABORT INTO {qi(current)} ({names}) VALUES ({params})"
                db.execute("BEGIN IMMEDIATE")
                db.execute(f"UPDATE {qi(PROGRESS)} SET expected_count=?,status='loading' WHERE table_name=?", (expected, current))
                pending = 0
                LOG.info(
                    "Loading %s: expected %s rows; already committed %s", current, f"{expected:,}", f"{rows:,}")
            elif kind == "batch":
                name, batch, batch_key, batch_hash = event[1:]
                if name != current:
                    raise LoadError("Internal reader/writer batch-order mismatch.")
                if not db.in_transaction:
                    db.execute("BEGIN IMMEDIATE")
                before = db.total_changes
                try:
                    db.executemany(insert_sql, batch)
                except sqlite3.Error as exc:
                    LOG.debug("Destination insert failed", exc_info=True)
                    raise LoadError(f"Insert into {name!r} failed: {error_label(exc)}. Current transaction will roll back; row values omitted.") from None
                if db.total_changes - before != len(batch):
                    raise LoadError("Inserted-row count does not match fetched-row count.")
                rows += len(batch)
                run_rows += len(batch)
                pending += len(batch)
                key = batch_key
                hash_sum = (hash_sum + batch_hash) % MODULUS
                if pending >= args.commit_rows:
                    checkpoint(db, name, rows, key, hash_sum, "loading")
                    pending = 0
                now = time.monotonic()
                if now - log_time >= args.log_seconds:
                    LOG.info("%s: %s / %s processed; %.0f rows/sec this session", name, f"{rows:,}", f"{expected:,}", run_rows / max(now-start_time, 0.001))
                    log_time = now
            elif kind == "end":
                name = event[1]
                if name != current or rows != expected:
                    raise LoadError(f"Source/fetched count mismatch for {name!r}; file will not be published.")
                if not db.in_transaction:
                    db.execute("BEGIN IMMEDIATE")
                actual = db.execute(f"SELECT COUNT(*) FROM {qi(name)}").fetchone()[0]
                if actual != expected:
                    raise LoadError(f"Destination/source count mismatch for {name!r}.")
                checkpoint(db, name, rows, key, hash_sum, "complete")
                checkpoint_wal(db)
                LOG.info("Copied %s: %s rows; count verified", name, f"{rows:,}")
                current = None
            else:
                raise LoadError("Unknown source event.")
        if current is not None:
            raise LoadError("Source stream ended during a table.")
    except BaseException:
        if db.in_transaction:
            db.rollback()
        raise


def checkpoint_wal(db: sqlite3.Connection) -> None:
    result = db.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
    if result[0] != 0:
        raise LoadError("WAL checkpoint blocked; another connection may be using the private staging file.")


def finalize(db: sqlite3.Connection, manifest: dict, args: argparse.Namespace) -> dict:
    states = progress_rows(db)
    if any(state["status"] != "complete" for state in states.values()):
        raise LoadError("Cannot finalize an incomplete load.")
    # Each saved DDL statement and its restored flag commit atomically.
    for name, kind, ddl in db.execute(f"SELECT name,kind,ddl FROM {qi(OBJECTS)} WHERE restored=0 ORDER BY kind,name").fetchall():
        LOG.info("Restoring %s %s", kind, name)
        with transaction(db):
            db.execute(ddl)
            db.execute(f"UPDATE {qi(OBJECTS)} SET restored=1 WHERE name=?", (name,))
        checkpoint_wal(db)
    if schema_fingerprint(db) != manifest["template_schema_hash"]:
        raise LoadError("Final application schema differs from the template.")
    results = []
    for plan in manifest["tables"]:
        name = plan["target_table"]
        state = states[name]
        count = db.execute(f"SELECT COUNT(*) FROM {qi(name)}").fetchone()[0]
        if count != state["expected"] or count != state["rows"]:
            raise LoadError(f"Final row count mismatch: {name!r}")
        item = {"source": f"{plan['source_schema']}.{plan['source_table']}", "target": name, "rows": count,
                "count_verified": True, "value_hash_verified": False}
        if manifest["verify_hash"]:
            LOG.info("Verifying copied values for %s", name)
            names = ",".join(qi(c["target"]) for c in plan["columns"])
            cursor = db.execute(f"SELECT {names} FROM {qi(name)}")
            actual_hash = 0
            while batch := cursor.fetchmany(args.batch_rows):
                for row in batch:
                    actual_hash = (actual_hash + row_hash(row)) % MODULUS
            if actual_hash != int(state["hash_sum"], 16):
                raise LoadError(f"Copied-value hash mismatch for {name!r}. SQLite coercion/collation/schema needs review.")
            item.update(value_hash_verified=True, unordered_sha256_sum=format(actual_hash, "064x"))
        results.append(item)
    LOG.info("Checking foreign keys")
    if db.execute("PRAGMA foreign_key_check").fetchone() is not None:
        raise LoadError("Foreign-key validation failed. The staged database is retained; no final file published.")
    db.execute("PRAGMA foreign_keys=ON")
    if db.execute("PRAGMA foreign_keys").fetchone()[0] != 1:
        raise LoadError("Could not enable foreign-key enforcement for final validation.")
    LOG.info("Running SQLite %s_check", args.integrity)
    checks = db.execute(f"PRAGMA {args.integrity}_check").fetchall()
    if checks != [("ok",)]:
        raise LoadError(f"SQLite {args.integrity}_check failed; no final file published.")
    if sqlite3.sqlite_version_info >= (3, 46, 0):
        db.execute("PRAGMA optimize=0x10002")
    else:
        db.execute("PRAGMA analysis_limit=1000")
        db.execute("ANALYZE")
    report = {"loader_version": VERSION, "validated_utc": utcnow(), "source": manifest["source"],
              "python_version": sys.version.split()[0], "sqlite_version": sqlite3.sqlite_version,
              "manifest_hash": digest(manifest), "integrity_check": args.integrity,
              "foreign_keys_verified": True, "tables": results,
              "hash_scope": "Copied columns after declared conversions; unordered sum of typed row SHA-256 hashes, not an authenticity proof.",
              "generated_and_defaulted_columns": "Excluded from value hashes; inspect the manifest and application schema."}
    with transaction(db):
        meta_set(db, "report", report)
        meta_set(db, "state", "validated")
    db.execute("PRAGMA synchronous=FULL")
    checkpoint_wal(db)
    mode = db.execute("PRAGMA journal_mode=DELETE").fetchone()[0]
    if mode.lower() != "delete":
        raise LoadError("Could not leave WAL mode before publishing a standalone SQLite file.")
    return report


def publish(stage: Path, output: Path, report: dict) -> None:
    for suffix in ("-wal", "-shm", "-journal"):
        sidecar = Path(str(stage) + suffix)
        if sidecar.exists() and sidecar.stat().st_size:
            raise LoadError(f"Nonempty SQLite sidecar remains: {sidecar}; publication refused.")
    with open(stage, "r+b") as handle:
        os.fsync(handle.fileno())
    # Same-directory hard-link publication is atomic and will NOT overwrite output.
    # Unlike rename on POSIX, this also refuses a concurrently-created output file.
    try:
        os.link(stage, output)
    except FileExistsError:
        raise LoadError(f"Output already exists; not overwritten: {output}") from None
    except OSError as exc:
        raise LoadError(f"Publication requires a local filesystem supporting hard links (for example NTFS/ext4/APFS): {error_label(exc)}. Validated staging file retained.") from None
    fsync_directory(output.parent)
    stage.unlink()
    fsync_directory(output.parent)
    # The complete report is already inside the output DB. This external copy is convenient only.
    report_path = Path(str(output) + ".report.json")
    try:
        with open(report_path, "x", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2)
            handle.write("\n")
    except OSError:
        LOG.warning("Database published; external report not written. The report remains in %s.", META)


def load_mapping(path: Path | None) -> dict:
    if path is None:
        return {}
    with open(path, encoding="utf-8-sig") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise LoadError("Mapping file must contain a JSON object.")
    return value


def run(args: argparse.Namespace) -> None:
    if sqlite3.sqlite_version_info < (3, 37, 0):
        raise LoadError("SQLite 3.37+ is required. Use a current, patched Python/SQLite build.")
    template = args.template.resolve()
    output = args.output.resolve()
    stage = output.with_name(output.name + ".loading.sqlite")
    if template in {output, stage}:
        raise LoadError("Template, output, and staging paths must differ.")
    if not output.parent.is_dir():
        raise LoadError("Create the protected local output directory first.")
    if output.exists():
        raise LoadError(f"Output already exists and will not be overwritten: {output}")
    config = load_mapping(args.mapping)
    source = None
    db = None
    with process_lock(Path(str(output) + ".lock")):
        if output.exists():
            raise LoadError("Output appeared while acquiring the lock; not overwritten.")
        if stage.exists() != args.resume:
            raise LoadError("Staging file exists: pass --resume, or use a new output filename." if stage.exists()
                            else "--resume was requested but no staging file exists.")
        template_db = read_only_sqlite(template)
        try:
            targets = inspect_template(template_db, args.defer_triggers)
            template_hash = schema_fingerprint(template_db)
            options = {"version": VERSION, "template_schema_hash": template_hash,
                       "source_mode": args.source_mode, "source_token": args.source_token,
                       "source_schema": args.source_schema, "mapping": config,
                       "decimal_mode": args.decimal_mode, "verify_hash": args.verify_hash,
                       "defer_triggers": args.defer_triggers, "keep_indexes": args.keep_indexes}
            options_hash = digest(options)
            if args.resume:
                db = sqlite3.connect(stage, isolation_level=None, timeout=30)
                manifest = meta_get(db, "manifest")
                if digest(manifest) != meta_get(db, "manifest_hash") or manifest["options_hash"] != options_hash:
                    raise LoadError("Resume configuration/template differs from the recorded load.")
                all_copied = all(s["status"] == "complete" for s in progress_rows(db).values())
                if not all_copied and args.source_mode != "static":
                    raise LoadError("Cannot resume partially copied data from a disconnected live SNAPSHOT transaction. "
                                    "Start a new output file for a fresh snapshot, or originally use a fixed static source.")
                if all_copied:
                    LOG.info("All source rows are already committed. Resuming local finalization without reconnecting to SQL Server.")
                else:
                    source, identity = connect_source(args)
                    plans = build_plan(source, targets, config, args)
                    compile_projections(source, plans)
                    if identity != manifest["source"] or plans != manifest["tables"]:
                        raise LoadError("Source identity or metadata changed; resume refused.")
            else:
                source, identity = connect_source(args)
                plans = build_plan(source, targets, config, args)
                manifest = {"version": VERSION, "options_hash": options_hash,
                            "source": identity, "template_schema_hash": template_hash,
                            "tables": plans, "verify_hash": args.verify_hash}
                compile_projections(source, plans)
                if args.dry_run:
                    for plan in plans:
                        LOG.info("Preflight OK: %s -> %s; %s copied columns; resume key: %s",
                                 qualified(plan), plan["target_table"], len(plan["columns"]), plan["resume_key"])
                    LOG.info("DRY RUN COMPLETE: no staging/output database created. Table row values/constraints have not been checked.")
                    return
                initialize_stage(template_db, stage, manifest, args)
                db = sqlite3.connect(stage, isolation_level=None, timeout=30)
            configure_destination(db, args)
            states = progress_rows(db)
            jobs = []
            for plan in manifest["tables"]:
                name = plan["target_table"]
                state = check_checkpoint(db, plan, states[name])
                states[name] = state
                if state["status"] != "complete":
                    jobs.append((plan, state))
            if jobs:
                if source is None:
                    raise LoadError("No source connection available for incomplete tables.")
                reader = SourceReader(source, jobs, args)
                source = None  # Ownership transfers to worker; only worker closes it.
                with reader:
                    consume(db, reader, states, args)
            report = finalize(db, manifest, args)
            db.close()
            db = None
            publish(stage, output, report)
            LOG.info("SUCCESS: %s (%s copied rows)", output, f"{sum(t['rows'] for t in report['tables']):,}")
        finally:
            template_db.close()
            if db is not None:
                with contextlib.suppress(Exception):
                    db.rollback()
                    db.close()
            if source is not None:
                close_source(source)


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--template", type=Path, required=True, help="Existing empty SQLite database with your application schema.")
    p.add_argument("--output", type=Path, required=True, help="NEW final SQLite path; never overwritten.")
    p.add_argument("--mapping", type=Path, help="Optional JSON mapping of source tables/columns to the template.")
    p.add_argument("--source-schema", default="dbo")
    p.add_argument("--connection-env", default="MSSQL_CONNECTION_STRING")
    p.add_argument("--source-mode", choices=("snapshot", "static"), default="snapshot")
    p.add_argument("--source-token", help="Required in static mode: stable identifier for the frozen backup/snapshot/source.")
    p.add_argument("--dry-run", action="store_true", help="Check connection, type probe, schema mappings and SELECT compilation; do not load data.")
    p.add_argument("--resume", action="store_true", help="Resume same staging file/config; partial-source resume requires static mode.")
    p.add_argument("--batch-rows", type=int, default=10_000)
    p.add_argument("--commit-rows", type=int, default=100_000)
    p.add_argument("--prefetch-batches", type=int, default=2)
    p.add_argument("--cache-mib", type=int, default=256)
    p.add_argument("--wal-mib", type=int, default=128, help="Approximate auto-checkpoint threshold, NOT a hard WAL size cap.")
    p.add_argument("--synchronous", choices=("full", "normal"), default="full")
    p.add_argument("--decimal-mode", choices=("text", "scaled_integer", "real"), default="text")
    p.add_argument("--keep-indexes", action="store_true", help="Do not defer non-unique secondary indexes.")
    p.add_argument("--defer-triggers", action="store_true", help="Explicitly drop/save and restore template triggers; they do not run during load.")
    p.add_argument("--verify-hash", action="store_true", help="Compare all copied values using an unordered hash; extra CPU and destination scan.")
    p.add_argument("--integrity", choices=("integrity", "quick"), default="integrity", help="Full integrity check by default; quick skips index/UNIQUE verification.")
    p.add_argument("--login-timeout", type=int, default=30)
    p.add_argument("--query-timeout", type=int, default=300, help="Seconds per ODBC statement; raise for very large/slow queries.")
    p.add_argument("--log-seconds", type=int, default=5)
    p.add_argument("--log-file", type=Path)
    p.add_argument("--debug-errors", action="store_true", help="Print raw exceptions/tracebacks; these MAY include source data or sensitive details.")
    return p


def main() -> int:
    args = parser().parse_args()
    for name in ("batch_rows", "commit_rows", "prefetch_batches", "cache_mib", "wal_mib", "login_timeout", "query_timeout", "log_seconds"):
        if getattr(args, name) <= 0:
            parser().error(f"--{name.replace('_','-')} must be positive")
    if args.source_mode == "static" and not args.source_token:
        parser().error("--source-mode static requires --source-token identifying an unchanged source")
    if args.dry_run and args.resume:
        parser().error("--dry-run and --resume cannot be combined")
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if args.log_file:
        handlers.append(logging.FileHandler(args.log_file, encoding="utf-8"))
    logging.basicConfig(level=logging.DEBUG if args.debug_errors else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s", handlers=handlers)
    LOG.info("Loader %s | Python %s | SQLite %s", VERSION, sys.version.split()[0], sqlite3.sqlite_version)
    v = sqlite3.sqlite_version_info
    wal_fix = v >= (3, 51, 3) or (v[:2] == (3, 44) and v[2] >= 6) or (v[:2] == (3, 50) and v[2] >= 7)
    if not wal_fix:
        LOG.warning("Use a SQLite build patched for the 2026 WAL-reset bug in production (3.51.3+, or maintained backport). This loader uses one exclusive SQLite connection, avoiding the documented concurrent-writer/checkpoint race.")
    try:
        run(args)
        return 0
    except KeyboardInterrupt:
        LOG.error("Interrupted. Current SQLite transaction rolled back; staging file retained.")
        return 130
    except Exception as exc:
        if args.debug_errors:
            LOG.exception("Load failed")
        else:
            LOG.error("%s", str(exc) if isinstance(exc, LoadError) else f"Load failed: {error_label(exc)}. Use --debug-errors for details.")
        LOG.error("No success reported. Inspect the staging file/configuration before retrying; never use a partial staging database in the application.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
